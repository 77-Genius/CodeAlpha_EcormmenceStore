const mongoose = require("mongoose");
const Product = require("../models/Product");

const escapeRegex = (value) =>
    value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// GET ALL PRODUCTS, WITH SEARCH AND CATEGORY FILTERING
const getProducts = async (req, res) => {
    try {
        const { search, category, sort } = req.query;
        const filter = {};

        if (category && category.toLowerCase() !== "all") {
            filter.category = new RegExp(
                `^${escapeRegex(category)}$`,
                "i"
            );
        }

        if (search && search.trim()) {
            const searchRegex = new RegExp(
                escapeRegex(search.trim()),
                "i"
            );

            filter.$or = [
                { name: searchRegex },
                { description: searchRegex },
                { category: searchRegex }
            ];
        }

        const sortOptions = {
            newest: { createdAt: -1 },
            price_asc: { price: 1 },
            price_desc: { price: -1 },
            name_asc: { name: 1 }
        };

        const products = await Product.find(filter)
            .sort(sortOptions[sort] || { createdAt: -1 });

        res.status(200).json({
            count: products.length,
            products
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch products",
            error: error.message
        });
    }
};

// GET A SINGLE PRODUCT BY ID
const getProductById = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.isObjectIdOrHexString(id)) {
            return res.status(400).json({
                message: "Invalid product ID"
            });
        }

        const product = await Product.findById(id);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.status(200).json(product);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch product",
            error: error.message
        });
    }
};

module.exports = {
    getProducts,
    getProductById
};