const mongoose = require("mongoose");
const User = require("../models/User");
const Product = require("../models/Product");
const Order = require("../models/Order");

// CHECKOUT: PLACE AN ORDER
const checkout = async (req, res) => {
    let reservedItems = [];
    let createdOrder = null;

    try {
        const user = await User.findById(req.user._id)
            .populate("cart.product");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        if (!user.cart.length) {
            return res.status(400).json({
                message: "Your cart is empty"
            });
        }

        const items = [];

        // Validate all products and quantities first.
        for (const cartItem of user.cart) {
            const product = cartItem.product;

            if (!product) {
                return res.status(400).json({
                    message: "A product in your cart no longer exists"
                });
            }

            if (product.stock < cartItem.quantity) {
                return res.status(400).json({
                    message: `Insufficient stock for ${product.name}. Available: ${product.stock}`
                });
            }

            items.push({
                product: product._id,
                name: product.name,
                price: product.price,
                quantity: cartItem.quantity
            });
        }

        // Calculate the total on the server, not from client input.
        const totalAmount = Number(
            items.reduce(
                (total, item) =>
                    total + item.price * item.quantity,
                0
            ).toFixed(2)
        );

        // Reduce stock only when sufficient stock remains.
        for (const item of items) {
            const result = await Product.updateOne(
                {
                    _id: item.product,
                    stock: { $gte: item.quantity }
                },
                {
                    $inc: { stock: -item.quantity }
                }
            );

            if (result.modifiedCount !== 1) {
                const error = new Error(
                    `Insufficient stock for ${item.name}. Please review your cart.`
                );
                error.code = "INSUFFICIENT_STOCK";
                throw error;
            }

            reservedItems.push(item);
        }

        // Save the order.
        createdOrder = await Order.create({
            user: user._id,
            items,
            totalAmount
        });

        // Empty the cart only after saving the order.
        user.cart = [];
        await user.save();

        return res.status(201).json({
            message: "Order placed successfully",
            order: createdOrder
        });

    } catch (error) {
        // Restore stock if checkout fails partway through.
        for (const item of reservedItems) {
            try {
                await Product.updateOne(
                    { _id: item.product },
                    { $inc: { stock: item.quantity } }
                );
            } catch (rollbackError) {
                console.error(
                    "Stock rollback failed:",
                    rollbackError.message
                );
            }
        }

        // Remove an order created by a checkout that did not finish.
        if (createdOrder) {
            try {
                await Order.deleteOne({
                    _id: createdOrder._id
                });
            } catch (rollbackError) {
                console.error(
                    "Order rollback failed:",
                    rollbackError.message
                );
            }
        }

        if (error.code === "INSUFFICIENT_STOCK") {
            return res.status(409).json({
                message: error.message
            });
        }

        console.error("Checkout error:", error.message);

        return res.status(500).json({
            message: "Checkout failed",
            error: error.message
        });
    }
};

// GET THE LOGGED-IN USER'S ORDERS
const getMyOrders = async (req, res) => {
    try {
        const orders = await Order.find({
            user: req.user._id
        }).sort({ createdAt: -1 });

        res.json({
            count: orders.length,
            orders
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to retrieve orders",
            error: error.message
        });
    }
};

// GET ONE ORDER BELONGING TO THE LOGGED-IN USER
const getOrderById = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.isObjectIdOrHexString(id)) {
            return res.status(400).json({
                message: "Invalid order ID"
            });
        }

        const order = await Order.findOne({
            _id: id,
            user: req.user._id
        });

        if (!order) {
            return res.status(404).json({
                message: "Order not found"
            });
        }

        res.json(order);

    } catch (error) {
        res.status(500).json({
            message: "Failed to retrieve order",
            error: error.message
        });
    }
};

module.exports = {
    checkout,
    getMyOrders,
    getOrderById
};