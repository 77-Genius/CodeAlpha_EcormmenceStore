const mongoose = require("mongoose");
const User = require("../models/User");
const Product = require("../models/Product");

const getCartDetails = (user) => {
    const items = user.cart
        .filter((item) => item.product)
        .map((item) => ({
            product: item.product,
            quantity: item.quantity,
            subtotal: Number(
                (item.product.price * item.quantity).toFixed(2)
            )
        }));

    return {
        items,
        totalItems: items.reduce(
            (total, item) => total + item.quantity,
            0
        ),
        totalAmount: Number(
            items.reduce(
                (total, item) => total + item.subtotal,
                0
            ).toFixed(2)
        )
    };
};

// GET THE LOGGED-IN USER'S CART
const getCart = async (req, res) => {
    try {
        const user = await User.findById(req.user._id)
            .populate(
                "cart.product",
                "name price image category stock"
            );

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.json({
            cart: getCartDetails(user)
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to retrieve cart",
            error: error.message
        });
    }
};

// ADD A PRODUCT TO THE CART
const addToCart = async (req, res) => {
    try {
        const { productId } = req.body;
        const quantity = Number(req.body.quantity ?? 1);

        if (!mongoose.isObjectIdOrHexString(productId)) {
            return res.status(400).json({
                message: "A valid product ID is required"
            });
        }

        if (!Number.isInteger(quantity) || quantity < 1) {
            return res.status(400).json({
                message: "Quantity must be a positive integer"
            });
        }

        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        const user = await User.findById(req.user._id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const existingItem = user.cart.find(
            (item) => item.product.toString() === productId
        );

        const newQuantity = existingItem
            ? existingItem.quantity + quantity
            : quantity;

        if (newQuantity > product.stock) {
            return res.status(400).json({
                message: `Only ${product.stock} units are available`
            });
        }

        if (existingItem) {
            existingItem.quantity = newQuantity;
        } else {
            user.cart.push({
                product: product._id,
                quantity
            });
        }

        await user.save();

        await user.populate(
            "cart.product",
            "name price image category stock"
        );

        res.status(200).json({
            message: "Product added to cart successfully",
            cart: getCartDetails(user)
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to add product to cart",
            error: error.message
        });
    }
};

// UPDATE A PRODUCT'S QUANTITY
const updateCartItem = async (req, res) => {
    try {
        const { productId } = req.params;
        const quantity = Number(req.body.quantity);

        if (!mongoose.isObjectIdOrHexString(productId)) {
            return res.status(400).json({
                message: "Invalid product ID"
            });
        }

        if (!Number.isInteger(quantity) || quantity < 1) {
            return res.status(400).json({
                message: "Quantity must be a positive integer"
            });
        }

        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        if (quantity > product.stock) {
            return res.status(400).json({
                message: `Only ${product.stock} units are available`
            });
        }

        const user = await User.findById(req.user._id);

        const item = user?.cart.find(
            (cartItem) => cartItem.product.toString() === productId
        );

        if (!item) {
            return res.status(404).json({
                message: "Product is not in your cart"
            });
        }

        item.quantity = quantity;

        await user.save();

        await user.populate(
            "cart.product",
            "name price image category stock"
        );

        res.json({
            message: "Cart quantity updated",
            cart: getCartDetails(user)
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to update cart",
            error: error.message
        });
    }
};

// REMOVE A PRODUCT FROM THE CART
const removeFromCart = async (req, res) => {
    try {
        const { productId } = req.params;

        if (!mongoose.isObjectIdOrHexString(productId)) {
            return res.status(400).json({
                message: "Invalid product ID"
            });
        }

        const user = await User.findById(req.user._id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const originalLength = user.cart.length;

        user.cart = user.cart.filter(
            (item) => item.product.toString() !== productId
        );

        if (user.cart.length === originalLength) {
            return res.status(404).json({
                message: "Product is not in your cart"
            });
        }

        await user.save();

        await user.populate(
            "cart.product",
            "name price image category stock"
        );

        res.json({
            message: "Product removed from cart",
            cart: getCartDetails(user)
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to remove product",
            error: error.message
        });
    }
};

// CLEAR THE ENTIRE CART
const clearCart = async (req, res) => {
    try {
        const user = await User.findById(req.user._id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        user.cart = [];
        await user.save();

        res.json({
            message: "Cart cleared successfully",
            cart: getCartDetails(user)
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to clear cart",
            error: error.message
        });
    }
};

module.exports = {
    getCart,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart
};