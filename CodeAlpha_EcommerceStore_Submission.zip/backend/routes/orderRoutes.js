const express = require("express");
const router = express.Router();

const protect = require("../middleware/authMiddleware");

const {
    checkout,
    getMyOrders,
    getOrderById
} = require("../controllers/orderController");

router.post("/checkout", protect, checkout);
router.get("/", protect, getMyOrders);
router.get("/:id", protect, getOrderById);

module.exports = router;