require("dotenv").config();

const mongoose = require("mongoose");
const Product = require("./models/Product");

const sampleProducts = [
    {
        name: "Wireless Headphones",
        description: "Comfortable wireless headphones with clear sound and long battery life.",
        price: 450,
        image: "https://placehold.co/600x400?text=Wireless+Headphones",
        category: "Electronics",
        stock: 25
    },
    {
        name: "Smart Watch",
        description: "A modern smartwatch for activity tracking and notifications.",
        price: 650,
        image: "https://placehold.co/600x400?text=Smart+Watch",
        category: "Electronics",
        stock: 18
    },
    {
        name: "Mechanical Keyboard",
        description: "A responsive mechanical keyboard for programming and gaming.",
        price: 380,
        image: "https://placehold.co/600x400?text=Mechanical+Keyboard",
        category: "Accessories",
        stock: 14
    },
    {
        name: "Laptop Backpack",
        description: "A durable backpack with a padded laptop compartment.",
        price: 220,
        image: "https://placehold.co/600x400?text=Laptop+Backpack",
        category: "Accessories",
        stock: 30
    },
    {
        name: "Bluetooth Speaker",
        description: "A portable Bluetooth speaker for music at home or on the go.",
        price: 300,
        image: "https://placehold.co/600x400?text=Bluetooth+Speaker",
        category: "Electronics",
        stock: 20
    },
    {
        name: "Desk Lamp",
        description: "An adjustable desk lamp for studying and working.",
        price: 160,
        image: "https://placehold.co/600x400?text=Desk+Lamp",
        category: "Home",
        stock: 12
    }
];

async function seedProducts() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);

        const existingCount = await Product.countDocuments();

        if (existingCount > 0) {
            console.log(
                `Database already contains ${existingCount} products. No changes made.`
            );
            return;
        }

        const products = await Product.insertMany(sampleProducts);

        console.log(`Successfully added ${products.length} products.`);
    } catch (error) {
        console.error("Seeding failed:", error.message);
        process.exitCode = 1;
    } finally {
        await mongoose.disconnect();
    }
}

seedProducts();