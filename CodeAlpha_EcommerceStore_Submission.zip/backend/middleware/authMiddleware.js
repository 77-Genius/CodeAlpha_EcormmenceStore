const jwt = require("jsonwebtoken");
const User = require("../models/User");

const protect = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({
                message: "Not authorized. Please log in."
            });
        }

        const token = authHeader.split(" ")[1];

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        const user = await User.findById(decoded.id)
            .select("-password")
            .maxTimeMS(5000);

        if (!user) {
            return res.status(401).json({
                message: "User not found"
            });
        }

        req.user = user;

        // Pass the authenticated request to the next handler.
        return next();

    } catch (error) {
        console.error("Authentication middleware error:", error.message);

        if (error.name === "MongooseError" ||
            error.name === "MongoServerError") {
            return res.status(503).json({
                message: "Database operation failed"
            });
        }

        return res.status(401).json({
            message: "Authentication failed. Please log in again."
        });
    }
};

module.exports = protect;