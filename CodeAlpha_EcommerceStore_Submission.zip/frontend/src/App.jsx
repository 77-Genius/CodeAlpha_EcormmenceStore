
import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:5001/api";

const money = (value) =>
  `GH₵${Number(value || 0).toLocaleString("en-GH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;

function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({ items: [], totalItems: 0, totalAmount: 0 });
  const [orders, setOrders] = useState([]);
  const [token, setToken] = useState(
    () => localStorage.getItem("ecommerce_token") || ""
  );
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("ecommerce_user") || "null");
    } catch {
      return null;
    }
  });

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [view, setView] = useState("shop");
  const [authMode, setAuthMode] = useState("login");
  const [showAuth, setShowAuth] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [notice, setNotice] = useState("");
  const [authError, setAuthError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  async function api(path, options = {}) {
    const headers = {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    };

    const response = await fetch(`${API}${path}`, {
      ...options,
      headers,
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.message || `Request failed (${response.status})`);
    }

    return data;
  }

  useEffect(() => {
    let cancelled = false;

    fetch(`${API}/products`)
      .then(async (response) => {
        if (!response.ok) throw new Error("Could not load products");
        return response.json();
      })
      .then((data) => {
        if (!cancelled) setProducts(data.products || []);
      })
      .catch((error) => {
        if (!cancelled) setNotice(error.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!token) {
      setCart({ items: [], totalItems: 0, totalAmount: 0 });
      return;
    }

    let cancelled = false;

    fetch(`${API}/cart`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Could not load cart");
        return data;
      })
      .then((data) => {
        if (!cancelled) setCart(data.cart);
      })
      .catch((error) => {
        if (!cancelled) setNotice(error.message);
      });

    return () => {
      cancelled = true;
    };
  }, [token]);

  const categories = useMemo(
    () => ["All", ...new Set(products.map((product) => product.category))],
    [products]
  );

  const visibleProducts = useMemo(() => {
    const query = search.trim().toLowerCase();

    return products.filter((product) => {
      const matchesSearch = [
        product.name,
        product.description,
        product.category,
      ].some((value) => String(value || "").toLowerCase().includes(query));

      const matchesCategory =
        category === "All" || product.category === category;

      return matchesSearch && matchesCategory;
    });
  }, [products, search, category]);

  async function submitAuth(event) {
    event.preventDefault();
    setAuthError("");
    setBusy(true);

    try {
      const payload = { email, password };
      if (authMode === "register") payload.name = name;

      const data = await api(`/auth/${authMode === "register" ? "register" : "login"}`, {
        method: "POST",
        body: JSON.stringify(payload),
      });

      localStorage.setItem("ecommerce_token", data.token);
      localStorage.setItem("ecommerce_user", JSON.stringify(data.user));

      setToken(data.token);
      setUser(data.user);
      setShowAuth(false);
      setPassword("");
      setNotice(`Welcome${data.user.name ? `, ${data.user.name}` : ""}!`);

    } catch (error) {
      setAuthError(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function addToCart(product) {
    if (!token) {
      setShowAuth(true);
      setAuthMode("login");
      setNotice("Please sign in to add products to your cart.");
      return;
    }

    try {
      const data = await api("/cart", {
        method: "POST",
        body: JSON.stringify({ productId: product._id, quantity: 1 }),
      });

      setCart(data.cart);
      setNotice(`${product.name} added to your cart.`);
      setSelectedProduct(null);
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function updateQuantity(productId, quantity) {
    try {
      if (quantity < 1) {
        const data = await api(`/cart/${productId}`, { method: "DELETE" });
        setCart(data.cart);
        return;
      }

      const data = await api(`/cart/${productId}`, {
        method: "PATCH",
        body: JSON.stringify({ quantity }),
      });

      setCart(data.cart);
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function removeFromCart(productId) {
    try {
      const data = await api(`/cart/${productId}`, { method: "DELETE" });
      setCart(data.cart);
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function openOrders() {
    if (!token) {
      setShowAuth(true);
      setAuthMode("login");
      return;
    }

    try {
      const data = await api("/orders");
      setOrders(data.orders || []);
      setView("orders");
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function checkout() {
    if (!token) {
      setShowAuth(true);
      setAuthMode("login");
      return;
    }

    if (!cart.items.length) {
      setNotice("Your cart is empty.");
      return;
    }

    setBusy(true);

    try {
      const result = await api("/orders/checkout", { method: "POST" });

      const [cartData, orderData] = await Promise.all([
        api("/cart"),
        api("/orders"),
      ]);

      setCart(cartData.cart);
      setOrders(orderData.orders || []);
      setView("orders");
      setNotice(
        `${result.message}. Order #${String(result.order._id).slice(-6).toUpperCase()}`
      );
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  function logout() {
    localStorage.removeItem("ecommerce_token");
    localStorage.removeItem("ecommerce_user");
    setToken("");
    setUser(null);
    setOrders([]);
    setView("shop");
    setNotice("You have signed out.");
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setView("shop")}>
          <span className="brand-icon">S</span>
          <span>ShopSphere<small>YOUR EVERYDAY STORE</small></span>
        </button>

        <nav className="navigation">
          <button className={view === "shop" ? "nav-link active" : "nav-link"} onClick={() => setView("shop")}>
            Shop
          </button>
          <button className={view === "orders" ? "nav-link active" : "nav-link"} onClick={openOrders}>
            My orders
          </button>
        </nav>

        <div className="header-actions">
          <button className="cart-button" onClick={() => setView("cart")}>
            <span>♧</span> Cart <b>{cart.totalItems || 0}</b>
          </button>

          {user ? (
            <div className="user-actions">
              <span className="welcome-user">Hi, {user.name || "Customer"}</span>
              <button className="text-button" onClick={logout}>Sign out</button>
            </div>
          ) : (
            <button className="primary-button small" onClick={() => {
              setAuthMode("login");
              setShowAuth(true);
            }}>
              Sign in
            </button>
          )}
        </div>
      </header>

      {notice && (
        <div className="notice">
          <span>{notice}</span>
          <button onClick={() => setNotice("")} aria-label="Dismiss">×</button>
        </div>
      )}

      {view === "shop" && (
        <main>
          <section className="hero">
            <div className="hero-copy">
              <span className="eyebrow">DISCOVER YOUR NEXT FAVOURITE</span>
              <h1>Good finds.<br /><span>Better everyday.</span></h1>
              <p>Explore tech, accessories and everyday essentials, all in one place.</p>
              <button className="primary-button" onClick={() =>
                document.getElementById("catalogue")?.scrollIntoView({ behavior: "smooth" })
              }>
                Explore collection <span>↗</span>
              </button>
              <div className="hero-stats">
                <span><b>{products.length}+</b> products to explore</span>
                <span><b>Secure</b> account access</span>
              </div>
            </div>
            <div className="hero-art" aria-hidden="true">
              <div className="art-circle circle-one" />
              <div className="art-circle circle-two" />
              <div className="art-card">
                <span className="art-label">CURATED FOR YOU</span>
                <div className="art-gift">✦</div>
                <strong>Everyday upgrades</strong>
                <span>Small things. Big difference.</span>
              </div>
              <span className="float-star star-one">✳</span>
              <span className="float-star star-two">✦</span>
            </div>
          </section>

          <section className="catalogue section-wrap" id="catalogue">
            <div className="section-heading">
              <div>
                <span className="eyebrow">THE COLLECTION</span>
                <h2>Shop our products</h2>
                <p>Useful picks for work, play and everything in between.</p>
              </div>
              <span className="product-count">{visibleProducts.length} products</span>
            </div>

            <div className="catalogue-tools">
              <div className="search-box">
                <span>⌕</span>
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search products..."
                  aria-label="Search products"
                />
                {search && <button onClick={() => setSearch("")}>×</button>}
              </div>

              <div className="category-list">
                {categories.map((item) => (
                  <button
                    key={item}
                    onClick={() => setCategory(item)}
                    className={category === item ? "category-chip selected" : "category-chip"}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            {loading ? (
              <div className="empty-state">Loading your collection...</div>
            ) : visibleProducts.length === 0 ? (
              <div className="empty-state">
                <span>⌕</span>
                <h3>No products found</h3>
                <p>Try another search or category.</p>
                <button className="secondary-button" onClick={() => {
                  setSearch("");
                  setCategory("All");
                }}>Clear filters</button>
              </div>
            ) : (
              <div className="product-grid">
                {visibleProducts.map((product, index) => (
                  <article className="product-card" key={product._id}>
                    <button
                      className={`product-image image-tone-${index % 4}`}
                      onClick={() => setSelectedProduct(product)}
                      aria-label={`View ${product.name}`}
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        loading="lazy"
                        onError={(event) => {
                          event.currentTarget.style.display = "none";
                        }}
                      />
                      <span className="image-category">{product.category}</span>
                    </button>

                    <div className="product-info">
                      <button className="product-name" onClick={() => setSelectedProduct(product)}>
                        {product.name}
                      </button>
                      <p>{product.description}</p>
                      <div className="product-bottom">
                        <strong>{money(product.price)}</strong>
                        <button
                          className="add-button"
                          onClick={() => addToCart(product)}
                          disabled={Number(product.stock) < 1}
                          aria-label={`Add ${product.name} to cart`}
                        >
                          {Number(product.stock) < 1 ? "Out of stock" : "+"}
                        </button>
                      </div>
                      <span className="stock-label">
                        {product.stock > 0 ? `${product.stock} available` : "Out of stock"}
                      </span>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
        </main>
      )}

      {view === "cart" && (
        <main className="page-panel section-wrap">
          <button className="back-link" onClick={() => setView("shop")}>← Continue shopping</button>
          <div className="page-title-row">
            <div><span className="eyebrow">YOUR SELECTION</span><h1>Shopping cart</h1></div>
            <span className="product-count">{cart.totalItems || 0} items</span>
          </div>

          {!token ? (
            <div className="empty-state">
              <h3>Sign in to view your cart</h3>
              <button className="primary-button" onClick={() => setShowAuth(true)}>Sign in</button>
            </div>
          ) : !cart.items?.length ? (
            <div className="empty-state">
              <span>🛍</span><h3>Your cart is waiting</h3>
              <p>Find something you love and add it here.</p>
              <button className="primary-button" onClick={() => setView("shop")}>Browse products</button>
            </div>
          ) : (
            <div className="cart-layout">
              <div className="cart-items">
                {cart.items.map((item) => {
                  const product = item.product;
                  if (!product) return null;

                  return (
                    <article className="cart-row" key={product._id}>
                      <img src={product.image} alt={product.name} />
                      <div className="cart-item-info">
                        <span className="eyebrow">{product.category}</span>
                        <h3>{product.name}</h3>
                        <strong>{money(product.price)}</strong>
                        <button className="remove-button" onClick={() => removeFromCart(product._id)}>
                          Remove
                        </button>
                      </div>
                      <div className="quantity-control">
                        <button onClick={() => updateQuantity(product._id, item.quantity - 1)}>−</button>
                        <span>{item.quantity}</span>
                        <button
                          disabled={item.quantity >= product.stock}
                          onClick={() => updateQuantity(product._id, item.quantity + 1)}
                        >+</button>
                      </div>
                      <strong className="line-total">{money(item.subtotal)}</strong>
                    </article>
                  );
                })}
              </div>

              <aside className="summary-card">
                <span className="eyebrow">ORDER SUMMARY</span>
                <h2>Your total</h2>
                <div className="summary-line"><span>Items ({cart.totalItems})</span><span>{money(cart.totalAmount)}</span></div>
                <div className="summary-line"><span>Delivery</span><span>Calculated separately</span></div>
                <div className="summary-total"><span>Subtotal</span><strong>{money(cart.totalAmount)}</strong></div>
                <button className="primary-button full-button" disabled={busy} onClick={checkout}>
                  {busy ? "Processing..." : "Place order →"}
                </button>
                <p className="secure-note">Your order will be saved to your account.</p>
              </aside>
            </div>
          )}
        </main>
      )}

      {view === "orders" && (
        <main className="page-panel section-wrap">
          <button className="back-link" onClick={() => setView("shop")}>← Continue shopping</button>
          <div className="page-title-row">
            <div><span className="eyebrow">YOUR ACCOUNT</span><h1>Order history</h1></div>
          </div>

          {!token ? (
            <div className="empty-state">
              <h3>Sign in to view your orders</h3>
              <button className="primary-button" onClick={() => setShowAuth(true)}>Sign in</button>
            </div>
          ) : orders.length === 0 ? (
            <div className="empty-state">
              <span>▤</span><h3>No orders yet</h3>
              <p>Your placed orders will appear here.</p>
              <button className="primary-button" onClick={() => setView("shop")}>Start shopping</button>
            </div>
          ) : (
            <div className="orders-list">
              {orders.map((order) => (
                <article className="order-card" key={order._id}>
                  <div className="order-head">
                    <div><span className="eyebrow">ORDER NUMBER</span><h3>#{String(order._id).slice(-8).toUpperCase()}</h3></div>
                    <span className="status-pill">{order.status}</span>
                  </div>
                  <div className="order-meta">
                    <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                    <span>{order.items.length} product line(s)</span>
                    <strong>{money(order.totalAmount)}</strong>
                  </div>
                  <div className="order-products">
                    {order.items.map((item, index) => (
                      <div className="order-product" key={`${order._id}-${index}`}>
                        <span>{item.name} × {item.quantity}</span>
                        <span>{money(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          )}
        </main>
      )}

      <footer className="footer">
        <button className="brand footer-brand" onClick={() => setView("shop")}>
          <span className="brand-icon">S</span>
          <span>ShopSphere<small>YOUR EVERYDAY STORE</small></span>
        </button>
        <p>Thoughtful finds for everyday living.</p>
        <span>© {new Date().getFullYear()} ShopSphere</span>
      </footer>

      {selectedProduct && (
        <div className="modal-backdrop" onClick={() => setSelectedProduct(null)}>
          <section className="product-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedProduct(null)}>×</button>
            <img src={selectedProduct.image} alt={selectedProduct.name} />
            <div className="product-modal-copy">
              <span className="eyebrow">{selectedProduct.category}</span>
              <h2>{selectedProduct.name}</h2>
              <p>{selectedProduct.description}</p>
              <strong className="modal-price">{money(selectedProduct.price)}</strong>
              <span className="stock-label">
                {selectedProduct.stock > 0 ? `${selectedProduct.stock} in stock` : "Out of stock"}
              </span>
              <button
                className="primary-button full-button"
                disabled={Number(selectedProduct.stock) < 1}
                onClick={() => addToCart(selectedProduct)}
              >Add to cart →</button>
            </div>
          </section>
        </div>
      )}

      {showAuth && (
        <div className="modal-backdrop" onClick={() => setShowAuth(false)}>
          <section className="auth-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setShowAuth(false)}>×</button>
            <div className="auth-symbol">S</div>
            <span className="eyebrow">WELCOME TO SHOPSPHERE</span>
            <h2>{authMode === "login" ? "Welcome back" : "Create your account"}</h2>
            <p>{authMode === "login" ? "Sign in to manage your cart and orders." : "Join us and start discovering everyday favourites."}</p>

            <form onSubmit={submitAuth}>
              {authMode === "register" && (
                <label>
                  Full name
                  <input value={name} onChange={(event) => setName(event.target.value)} required minLength={2} />
                </label>
              )}
              <label>
                Email address
                <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
              </label>
              <label>
                Password
                <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={6} />
              </label>
              {authError && <div className="form-error">{authError}</div>}
              <button className="primary-button full-button" type="submit" disabled={busy}>
                {busy ? "Please wait..." : authMode === "login" ? "Sign in →" : "Create account →"}
              </button>
            </form>

            <div className="auth-switch">
              {authMode === "login" ? "New to ShopSphere?" : "Already have an account?"}
              <button onClick={() => {
                setAuthMode(authMode === "login" ? "register" : "login");
                setAuthError("");
              }}>
                {authMode === "login" ? "Create account" : "Sign in"}
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;
