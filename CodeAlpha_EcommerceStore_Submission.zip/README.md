# ShopSphere — CodeAlpha E-commerce Store

A full-stack e-commerce application developed as part of the CodeAlpha Full Stack Web Development Internship.

## Overview

ShopSphere is an online store where customers can browse products, search the catalogue, manage a shopping cart, place orders, and view their order history.

## Features

- User registration and login
- JWT-based authentication
- Password hashing with bcrypt
- Product catalogue and individual product details
- Product search, category filtering, and sorting
- Shopping cart with quantity management
- Stock validation during cart updates and checkout
- Order creation and order history
- MongoDB database integration
- REST APIs built with Express.js
- Responsive React storefront

## Technology Stack

**Frontend:** React, Vite, JavaScript, CSS

**Backend:** Node.js, Express.js

**Database:** MongoDB Atlas, Mongoose

**Authentication:** JSON Web Tokens (JWT), bcryptjs

## Project Structure

```text
CodeAlpha_EcommerceStore/
├── backend/
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── server.js
│   ├── package.json
│   └── .env
├── frontend/
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── index.html
├── .gitignore
└── README.md
```

## Requirements

- Node.js and npm
- A MongoDB Atlas database or another accessible MongoDB deployment

## Configuration

Create `backend/.env` with the following variables:

```env
PORT=5001
MONGODB_URI=YOUR_MONGODB_CONNECTION_STRING
JWT_SECRET=YOUR_PRIVATE_JWT_SECRET
```

Replace the placeholders with your own values. The MongoDB connection string should target the `ecommerce_store` database.

Never commit your real `.env` file or expose database credentials.

## Installation and Setup

### 1. Install backend dependencies

```powershell
cd backend
npm.cmd install
```

### 2. Start the backend

```powershell
npm.cmd run dev
```

The API runs on `http://localhost:5001` by default.

### 3. Install frontend dependencies

Open a second terminal:

```powershell
cd frontend
npm.cmd install
```

### 4. Start the frontend

```powershell
npm.cmd run dev
```

Open the local URL printed by Vite, commonly `http://localhost:5173`.

Keep both development servers running while using the application.

### 5. Create sample products

If the database does not yet contain products, run the backend seed script:

```powershell
cd backend
node seedProducts.js
```

The script adds sample products when the products collection is empty.

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Register a customer |
| POST | `/api/auth/login` | Authenticate a customer |
| GET | `/api/products` | List and filter products |
| GET | `/api/products/:id` | Get product details |
| GET | `/api/cart` | Retrieve the customer's cart |
| POST | `/api/cart` | Add a product to the cart |
| PATCH | `/api/cart/:productId` | Update quantity |
| DELETE | `/api/cart/:productId` | Remove a cart item |
| DELETE | `/api/cart` | Clear the cart |
| POST | `/api/orders/checkout` | Place an order |
| GET | `/api/orders` | View order history |
| GET | `/api/orders/:id` | Retrieve a specific order |

Cart and order endpoints require a valid JWT access token.

Product listing supports search, category filtering, and sorting through query parameters.

## Production Build

To build the frontend for deployment:

```powershell
cd frontend
npm.cmd run build
```

The production files are generated in `frontend/dist/`.

## Notes

- The application uses a MongoDB connection configured through environment variables.
- Product prices in the sample catalogue are displayed in Ghanaian cedis (GH₵).
- Checkout creates an order and validates stock. A payment gateway is not currently integrated.
- The local frontend configuration uses the backend at `http://localhost:5001/api`.

## Internship Project

**Program:** CodeAlpha Full Stack Web Development Internship

**Project:** E-commerce Store
